import subprocess
import time
import requests
import os
import signal
import sys
import threading
from datetime import datetime

# ================= 全局配置 =================

WORKER_URL = "https://tv.n2nj.moe"
FIXED_STREAM_URL = "https://stream.n2nj.moe"

ADMIN_ACCOUNT = "sumie"
ADMIN_PASSWORD = "12qwaszx34$"
# 【关键】WAF 通行证密钥 (必须与 CF WAF 规则一致)
WAF_SECRET_KEY = "N2NJ_SUPER_SECRET_PASS_2026_7684" 

HLS_ROOT_DIR = r"D:\StreamServ\nginx\html\stream"

# 频道配置
CHANNELS = [
    {
        "name": "主频道",
        "udp_port": 22701,
        "pid": "22-7", 
        "m3u8_name": "live.m3u8"
    },
    {
        "name": "备用频道",
        "udp_port": 22702,
        "pid": "22-7-sub",
        "m3u8_name": "sub.m3u8"
    }
]

# ============================================

# 定义通用的请求头
def get_headers():
    return {
        "User-Agent": "N2NJ-Stream-Bot/1.0",
        "X-Bypass-WAF": WAF_SECRET_KEY, # 这张牌必须时刻带着
        "Content-Type": "application/json"
    }

def get_auth_cookie():
    for _ in range(3):
        try:
            res = requests.post(
                f"{WORKER_URL}/api/auth/login", 
                json={"username": ADMIN_ACCOUNT, "password": ADMIN_PASSWORD}, 
                headers=get_headers(), # <--- 第一次出示金牌
                timeout=10
            )
            
            if res.status_code == 200:
                if "error" in res.text:
                    print(f"❌ 登录拒绝: {res.text}")
                    return None
                return res.cookies
        except:
            time.sleep(2)
    print("❌ 登录失败: 无法连接到 Worker")
    return None

def get_real_db_id(target_pid, cookies):
    try:
        # 【关键修复】这里之前忘了传 headers，导致被 WAF 拦截
        res = requests.get(
            f"{WORKER_URL}/api/players", 
            cookies=cookies, 
            headers=get_headers(), # <--- 必须补上这张金牌
            timeout=10
        )
        
        if res.status_code == 200:
            # 尝试解析 JSON，如果被 WAF 拦截返回 HTML，这里会抛错
            data = res.json()
            for p in data:
                pid_val = p.get('pId') or p.get('p_id')
                if str(pid_val) == str(target_pid):
                    return p.get('id')
        else:
            print(f"⚠️ 获取列表失败 (HTTP {res.status_code}) - 可能是 WAF 拦截")
            # 调试用：打印返回的前100个字符看看是不是 HTML
            print(f"返回内容片段: {res.text[:100]}")
            
    except Exception as e:
        print(f"⚠️ 解析列表异常: {e}")
    return None

def sync_web_status(channel_conf, is_on_air):
    cookies = get_auth_cookie()
    if not cookies: return

    target_pid = channel_conf['pid']
    # 传递 headers 是在 get_real_db_id 内部处理的，这里不用变
    db_id = get_real_db_id(target_pid, cookies)
    
    if db_id is None:
        print(f"⛔ [{channel_conf['name']}] 未找到 ID 为 {target_pid} 的播放器 (或被 WAF 拦截)")
        return

    api_url = f"{WORKER_URL}/api/players/{db_id}"
    m3u8_url = f"{FIXED_STREAM_URL}/stream/{channel_conf['m3u8_name']}"

    if is_on_air:
        payload = {
            "name": f"【ON AIR】{channel_conf['name']}",
            "pId": target_pid,
            "url": m3u8_url,
            "description": f"正在直播 | H264 2.8M P7Bf3 | {datetime.now().strftime('%H:%M')}",
            "coverUrl": "", 
            "announcement": ""
        }
        print(f"🟢 [{channel_conf['name']}] -> ON AIR")
    else:
        payload = {
            "name": f"【中断】{channel_conf['name']}",
            "pId": target_pid,
            "url": "http://offline", 
            "description": f"信号等待中... | 采集离线 | {datetime.now().strftime('%H:%M:%S')}",
            "coverUrl": "",
            "announcement": ""
        }
        print(f"🔴 [{channel_conf['name']}] -> 中断")

    try:
        # 这里也要带金牌
        requests.put(
            api_url, 
            json=payload, 
            cookies=cookies, 
            headers=get_headers(), # <--- 再次出示金牌
            timeout=10
        )
    except Exception as e:
        print(f"❌ 网络异常: {e}")

class ChannelThread(threading.Thread):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.stop_event = threading.Event()
        self.process = None
        self.m3u8_path = os.path.join(HLS_ROOT_DIR, self.config['m3u8_name'])
        self.last_status = None 

    def update_state(self, is_active):
        if self.last_status != is_active:
            self.last_status = is_active
            sync_web_status(self.config, is_active)

    def run(self):
        print(f"🛡️ 启动监听: {self.config['name']} (Port {self.config['udp_port']})")
        self.update_state(False)

        while not self.stop_event.is_set():
            self.start_ffmpeg()
            startup_time = time.time()
            
            while self.process and self.process.poll() is None:
                if self.stop_event.is_set(): break
                
                is_warming_up = (time.time() - startup_time) < 15

                if self.check_file_heartbeat():
                    self.update_state(True)
                else:
                    if not is_warming_up:
                        self.update_state(False)
                        if self.process.poll() is None:
                            self.process.terminate()
                            break 
                
                time.sleep(2)

            self.update_state(False)
            
            if not self.stop_event.is_set():
                time.sleep(3) 

    def check_file_heartbeat(self):
        if not os.path.exists(self.m3u8_path): return False
        try:
            mtime = os.path.getmtime(self.m3u8_path)
            if time.time() - mtime < 12: return True
        except: pass
        return False

    def start_ffmpeg(self):
        if os.path.exists(self.m3u8_path):
            try: os.remove(self.m3u8_path)
            except: pass

        cmd = [
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-hwaccel", "cuda", "-hwaccel_output_format", "cuda",
            "-probesize", "20000000", "-analyzeduration", "20000000",
            "-i", f"udp://0.0.0.0:{self.config['udp_port']}?fifo_size=1000000&overrun_nonfatal=1&timeout=10000000&reuse=1",
            "-map", "0:v:0", "-map", "0:a:0",
            "-ignore_unknown",
            "-c:v", "h264_nvenc", "-profile:v", "high", "-preset", "p7",
            "-rc", "cbr", "-b:v", "2800k", "-maxrate", "2800k", "-bufsize", "10000k",
            "-bf", "3", "-b_ref_mode", "middle", "-temporal-aq", "1", "-spatial-aq", "1",
            "-vf", "yadif_cuda=0:-1:0",
            "-g", "120", "-keyint_min", "120", "-sc_threshold", "0",
            "-c:a", "aac", "-b:a", "192k", "-ac", "2",
            "-f", "hls", "-hls_time", "4", "-hls_list_size", "6", "-hls_flags", "delete_segments",
            self.m3u8_path
        ]
        self.process = subprocess.Popen(cmd)

    def stop(self):
        self.stop_event.set()
        if self.process and self.process.poll() is None:
            self.process.terminate()

def main():
    threads = []
    print(f"🚀 直播服务 v4.7 | WAF通行证修复版")
    print("==================================================")
    
    if not os.path.exists(HLS_ROOT_DIR): os.makedirs(HLS_ROOT_DIR)

    for conf in CHANNELS:
        t = ChannelThread(conf)
        t.start()
        threads.append(t)

    try:
        while True: time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        print("\n停止服务...")
        for t in threads: t.stop()
        subprocess.run("taskkill /F /IM ffmpeg.exe", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == "__main__":
    main()